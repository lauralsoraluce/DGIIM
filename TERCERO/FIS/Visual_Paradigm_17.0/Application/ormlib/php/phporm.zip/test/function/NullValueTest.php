<?php
/*
 * Created on Jul 29, 2005
 *
 */
 	require_once( realpath(dirname(__FILE__)).'/../../ezpdo_runtime.php');
 	require_once( realpath(dirname(__FILE__)).'/../../libs/simpletest/unit_tester.php');
  	require_once( realpath(dirname(__FILE__)).'/../../libs/simpletest/reporter.php');
	class NullValueTest extends UnitTestCase {
		
		function NullValueTest(){
 			$this->UnitTestCase('Null Value Test');	
 		}
 		
		function testNullValue(){
			
			$link = mysql_connect('localhost', 'root', '');
			mysql_select_db('ezpdo', $link);
			mysql_query('CREATE TABLE `NullValueTestObj` (`oid` int primary key auto_increment, `name` char(60), `age` int);');							
			mysql_query('INSERT INTO `NullValueTestObj`(`name`) VALUES (\'abc\');');
			mysql_close($link);
			try{
				$m = epManager::instance();
				$n = $m->create('NullValueTestObj');
				$n->name = 'abc';
				$n->commit();
				$ts = $m->get('NullValueTestObj', false, EP_GET_FROM_DB);
				$this->assertTrue(is_null($ts[0]->age));
				$this->assertEqual($ts[0]->name, 'abc');
			}catch (Exception $e) {
				$this->fail('Caught exception: ' . $e->getMessage());
			}
		}
	}
	
	$test = &new NullValueTest();
 	$test->run(new HtmlReporter());
?>
 