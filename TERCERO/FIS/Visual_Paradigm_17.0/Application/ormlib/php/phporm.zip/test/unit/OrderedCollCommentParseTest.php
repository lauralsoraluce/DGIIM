<?php
require_once (realpath(dirname(__FILE__)).'/../../ezpdo_runtime.php');
require_once (realpath(dirname(__FILE__)).'/../../src/compiler/epComment.php');
require_once (realpath(dirname(__FILE__)).'/../../libs/simpletest/unit_tester.php');
require_once (realpath(dirname(__FILE__)).'/../../libs/simpletest/reporter.php');

class OrderedCollCommentParseTest extends UnitTestCase {
	function OrderedCollCommentParseTest() {
		$this->UnitTestCase('List Parse test');
	}

	function testAttributeHasList() {
		$com = '/**';
		$com .= '* @orm has many Book inverse(authorvar)';
		$com .= '* @dbva inverse(authorvar) collection(authorIndex,int)';
		$com .= '*/';

		$c = new epComment($com);
		$value = $c->getTagValue('dbva');

		$t = new dbvaVarTag($value);
		$this->assertEqual($t->get('collection'), 'authorIndex');
		$this->assertEqual($t->get('collection_type'), 'int');
	}
}
$test = & new OrderedCollCommentParseTest();
$test->run(new HtmlReporter());
?>


