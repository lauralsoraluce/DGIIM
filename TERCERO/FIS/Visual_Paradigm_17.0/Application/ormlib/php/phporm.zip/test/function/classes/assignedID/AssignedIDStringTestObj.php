<?php
/*
 * Created on Jul 30, 2005
 *
 */
 class AssignedIDStringTestObj {
	/**
	 * @var string
	 * @orm char(60)
	 * @dbva id(assigned)
	 */
	private $id;
	
	/**
	 * @var string
	 * @orm char(20)
	 */
	private $name;

	public function &getId() {
		return $this->id;
	}

	public function setId(&$id) {
		$this->id = $id;
	}

	public function &getName() {
		return $this->name;
	}

	public function setName(&$name) {
		$this->name = $name;
	}
}
?>
