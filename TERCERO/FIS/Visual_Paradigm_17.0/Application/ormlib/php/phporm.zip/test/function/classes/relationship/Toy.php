<?php
/*
 * Created on Aug 13, 2005 4:39:58 PM
 * author : Administrator
 */
 class Toy{
 	
 	/**
 	 * @orm has one Child 
 	 * @dbva fk(childid)  
 	 */
 	 private $childX;
 	 
 	/**
 	 * @var int
 	 * @orm toyid int
 	 * @dbva id(autogenerate)
 	 */
 	private $toy_id;
 	
// 	/**
// 	 * @var string
// 	 * @orm toyid2 char
// 	 * @dbva id(assigned)
// 	 */
// 	public $toy_id2;
 	
 	/**
 	 * @var string
 	 * @orm toyName char
 	 */
 	private $toyName;

 	public function &getChildX() {
 		return $this->childX;
 	}

 	public function setChildX(&$childX) {
 		$this->childX = $childX;
 	}

 	public function &getToy_id() {
 		return $this->toy_id;
 	}

 	public function setToy_id(&$toy_id) {
 		$this->toy_id = $toy_id;
 	}

 	public function &getToyName() {
 		return $this->toyName;
 	}

 	public function setToyName(&$toyName) {
 		$this->toyName = $toyName;
 	}
 }
?>
