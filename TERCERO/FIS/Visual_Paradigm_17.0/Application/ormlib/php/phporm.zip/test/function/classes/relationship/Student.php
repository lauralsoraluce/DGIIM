<?php
/*
 * Created on Aug 19, 2005 11:41:06 AM
 * author : Administrator
 */
 	class Student{
 		/**
		 * @var int
		 * @orm id int
		 * @dbva id(assigned)
		*/
		private $studentID;
		
		/**
		 * @var string
		 * @orm name char
		*/
		private $studentname;
	 	
	 	/**
	 	 * @orm composed_of many Course
	 	 * @dbva jointable(course_student) fk(studentID) inversefk(courseID)
	 	 */
	 	 private $courses;
		
		public function &getStudentID() {
			return $this->studentID;
		}
		
		public function setStudentID(&$studentID) {
			$this->studentID = $studentID;
		}
		
		public function &getStudentname() {
			return $this->studentname;
		}
		
		public function setStudentname(&$studentname) {
			$this->studentname = $studentname;
		}
		
		public function &getCourses() {
			return $this->courses;
		}
		
		public function setCourses(&$courses) {
			$this->courses = $courses;
		}
 	}
?>
