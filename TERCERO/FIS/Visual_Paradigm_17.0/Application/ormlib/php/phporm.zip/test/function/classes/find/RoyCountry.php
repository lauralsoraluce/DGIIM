<?php
/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Demo
 * License Type: Purchased
 */

/**
 * @orm RoyCountry
 */
class RoyCountry {
  /**
   * @orm countryId char
   * @dbva id(assigned) 
   */
  private $countryId;
  
  /**
   * @orm countryName char
   */
  private $countryName;
  
  /**
   * @orm has one RoyAddress inverse(royCountries)
   * @dbva fk(RoyAddressaddressId) 
   */
  private $royAddress;
  
  public function &getCountryId() {
    return $this->countryId;
  }
  
  
  public function setCountryId(&$countryId) {
    $this->countryId = $countryId;
  }
  
  
  public function &getCountryName() {
    return $this->countryName;
  }
  
  
  public function setCountryName(&$countryName) {
    $this->countryName = $countryName;
  }
  
  
  public function &getRoyAddress() {
    return $this->royAddress;
  }
  
  
  public function setRoyAddress(&$royAddress) {
    $this->royAddress = $royAddress;
  }
  
  
  public function __toString() {
    $s = '';
    $s .= $this->countryId;
    return $s;
  }
  
}

?>
