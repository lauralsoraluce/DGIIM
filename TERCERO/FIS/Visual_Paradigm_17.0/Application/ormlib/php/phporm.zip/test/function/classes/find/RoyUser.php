<?php
/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Demo
 * License Type: Purchased
 */

/**
 * @orm RoyUser
 */
class RoyUser {
  /**
   * @orm userId char
   * @dbva id(assigned) 
   */
  private $userId;
  
  /**
   * @orm userName char
   */
  private $userName;
  
  /**
   * @orm has many RoyAddress inverse(royUser)
   * @dbva inverse(RoyUseruserId) 
   */
  private $royAddresses;
  
  public function &getUserId() {
    return $this->userId;
  }
  
  
  public function setUserId(&$userId) {
    $this->userId = $userId;
  }
  
  
  public function &getUserName() {
    return $this->userName;
  }
  
  
  public function setUserName(&$userName) {
    $this->userName = $userName;
  }
  
  
  public function &getRoyAddresses() {
    return $this->royAddresses;
  }
  
  
  public function setRoyAddresses(&$royAddresses) {
    $this->royAddresses = $royAddresses;
  }
  
  
  public function __toString() {
    $s = '';
    $s .= $this->userId;
    return $s;
  }
  
}

?>
