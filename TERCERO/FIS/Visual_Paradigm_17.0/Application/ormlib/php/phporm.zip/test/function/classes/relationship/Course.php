<?php
/*
 * Created on Aug 19, 2005 11:40:55 AM
 * author : Administrator
 */
	 class Course{
		/**
		 * @var string
		 * @orm id char
		 * @dbva id(assigned)
		*/
		private $courseID;
		
		/**
		 * @var string
		 * @orm name char
		*/
		private $coursename;
	 	
	 	/**
	 	 * @orm composed_of many Student
	 	 * @dbva jointable(course_student) fk(courseID) inversefk(studentID)
	 	 */
	 	 private $students;
		
		public function &getCourseID() {
			return $this->courseID;
		}
		
		public function setCourseID(&$courseID) {
			$this->courseID = $courseID;
		}
		
		public function &getCoursename() {
			return $this->coursename;
		}
		
		public function setCoursename(&$coursename) {
			$this->coursename = $coursename;
		}
		
		public function &getStudents() {
			return $this->students;
		}
		
		public function setStudents(&$students) {
			$this->students = $students;
		}
	 }
?>
