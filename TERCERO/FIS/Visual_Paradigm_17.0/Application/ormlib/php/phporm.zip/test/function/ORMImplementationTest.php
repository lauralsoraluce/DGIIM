<?php
require_once (realpath(dirname(__FILE__)).'/../../ezpdo_runtime.php');
require_once (realpath(dirname(__FILE__)).'/../../libs/simpletest/unit_tester.php');
require_once (realpath(dirname(__FILE__)).'/../../libs/simpletest/reporter.php');
class ORMImplementationTest extends UnitTestCase{
	function ORMImplementationTest() {
		$this->UnitTestCase('orm implementation test');
		$this->_setUp();
	}
	
	function _setUp(){
		$link = mysql_connect('localhost', 'root', '');
		mysql_select_db('ezpdo', $link);
		
		mysql_query('DROP TABLE `Customer`');
		mysql_query('CREATE TABLE `Customer`(id varchar(60) primary key, name varchar(100), account varchar(100), address varchar(100));');
		
		mysql_close($link);
	}
	
	function testClassParse(){
		$m = epManager::instance();
		$customer = $m->create('Customer');
		$customer->customerID = 'c1';
		$customer->customerName = 'mingkit';
		$customer->account = 'account';
		$customer->address = 'address';
		$this->assertEqual($customer->ccc(), "c1-mingkit-account-address");
		$customer->commit();
		
		$m->clearAllCached();
		$c = $m->get('Customer', false, 1);
		//call implementation class method
		$this->assertEqual($c[0]->ccc(), "c1-mingkit-account-address");
	}
}

$test = & new ORMImplementationTest();
$test->run(new HtmlReporter());
?>
