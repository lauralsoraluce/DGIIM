<?php
/*
 * Created on Jul 29, 2005
 *
 */
class AssignedIntIDTestObj {
	/**
	 * @var int
	 * @orm id int
	 * @dbva id(assigned)
	 */
	private $id;
	
	/**
	 * @var string
	 * @orm char(20)
	 */
	private $name;

	public function &getId() {
		return $this->id;
	}

	public function setId(&$id) {
		$this->id = $id;
	}

	public function &getName() {
		return $this->name;
	}

	public function setName(&$name) {
		$this->name = $name;
	}
}
?>
