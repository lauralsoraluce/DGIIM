<?php
/*
 * Created on Jul 29, 2005
 *
 */
 class NullValueTestObj {
		/**
		 * @var string
		 * @orm char(20)
		 */
		private $name;
		
		/**
		 * @var int
		 * @orm int
		 */
		private $age;

		public function &getName() {
			return $this->name;
		}

		public function setName(&$name) {
			$this->name = $name;
		}

		public function &getAge() {
			return $this->age;
		}

		public function setAge(&$age) {
			$this->age = $age;
		}
	}
?>
