<?php
/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Demo
 * License Type: Purchased
 */

/**
 * @orm RoyAddress
 */
class RoyAddress {
  /**
   * @orm addressId char
   * @dbva id(assigned) 
   */
  private $addressId;
  
  /**
   * @orm addressName char
   */
  private $addressName;
  
  /**
   * @orm has one RoyUser inverse(royAddresses)
   * @dbva fk(RoyUseruserId) 
   */
  private $royUser;
  
  /**
   * @orm has many RoyCountry inverse(royAddress)
   * @dbva inverse(RoyAddressaddressId) 
   */
  private $royCountries;
  
  public function &getAddressId() {
    return $this->addressId;
  }
  
  
  public function setAddressId(&$addressId) {
    $this->addressId = $addressId;
  }
  
  
  public function &getAddressName() {
    return $this->addressName;
  }
  
  
  public function setAddressName(&$addressName) {
    $this->addressName = $addressName;
  }
  
  
  public function &getRoyUser() {
    return $this->royUser;
  }
  
  
  public function setRoyUser(&$royUser) {
    $this->royUser = $royUser;
  }
  
  
  public function &getRoyCountries() {
    return $this->royCountries;
  }
  
  
  public function setRoyCountries(&$royCountries) {
    $this->royCountries = $royCountries;
  }
  
  
  public function __toString() {
    $s = '';
    $s .= $this->addressId;
    return $s;
  }
  
}

?>
