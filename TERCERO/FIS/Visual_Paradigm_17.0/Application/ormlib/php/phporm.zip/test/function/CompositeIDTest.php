<?php
/*
 * Created on Aug 10, 2005 11:27:36 AM
 * author : Administrator
 */
 	require_once( realpath(dirname(__FILE__)).'/../../ezpdo_runtime.php');
 	require_once( realpath(dirname(__FILE__)).'/../../libs/simpletest/unit_tester.php');
  	require_once( realpath(dirname(__FILE__)).'/../../libs/simpletest/reporter.php');
	class CompositeIDTest extends UnitTestCase{
		function CompositeIDTest(){
			$this->UnitTestCase('CompositeIDTest');
			$this->_setUp();
		}
		
		function _setUp(){
			$link = mysql_connect('localhost', 'root', '');
			mysql_select_db('ezpdo', $link);
			mysql_query('DROP TABLE `CompositeIntOnly`;');
			mysql_query('CREATE TABLE `CompositeIntOnly`(`id1` int, `id2` int, `name` char(60), PRIMARY KEY  (`id1`,`id2`));');
			
			mysql_query('DROP TABLE `CompositeStringOnly`;');
			mysql_query('CREATE TABLE `CompositeStringOnly`(`id1` varchar(60), `id2` varchar(60), `name` char(60), PRIMARY KEY  (`id1`,`id2`));');
			
			mysql_query('DROP TABLE `CompositeIntString`;');
			mysql_query('CREATE TABLE `CompositeIntString`(`id1` varchar(60), `id2` int, `name` char(60), PRIMARY KEY  (`id1`,`id2`));');
			mysql_close($link);
		}
		
		function testCompositeInt(){
			$m = epManager::instance();
			$cm = $m->getClassMap('CompositeIntOnly');
			$fms = $cm->getAllFields();
			foreach($fms as $fm){
				if($fm->getName() == 'id1'){
					$this->assertTrue($fm->isID());
					$this->assertEqual($fm->getIDType(), 'assigned');
				}
				else if($fm ->getName() == 'id2'){
					$this->assertTrue($fm->isID());
					$this->assertEqual($fm->getIDType(), 'assigned');	
				}	
			}	
		}
		
		function testCompositeString(){
			$m = epManager::instance();
			$cm = $m->getClassMap('CompositeStringOnly');
			$fms = $cm->getAllFields();
			foreach($fms as $fm){
				if($fm->getName() == 'id1'){
					$this->assertTrue($fm->isID());
					$this->assertEqual($fm->getIDType(), 'assigned');
				}
				else if($fm ->getName() == 'id2'){
					$this->assertTrue($fm->isID());
					$this->assertEqual($fm->getIDType(), 'assigned');	
				}	
			}	
		}
		
		function testCompositeIntString(){
			$m = epManager::instance();
			$cm = $m->getClassMap('CompositeIntString');
			$fms = $cm->getAllFields();
			foreach($fms as $fm){
				if($fm->getName() == 'id1'){
					$this->assertTrue($fm->isID());
					$this->assertEqual($fm->getIDType(), 'assigned');
				}
				else if($fm ->getName() == 'id2'){
					$this->assertTrue($fm->isID());
					$this->assertEqual($fm->getIDType(), 'assigned');	
				}	
			}	
		}
		
		function testCompositeIntProcess(){
			$m = epManager::instance();
			$intOnly = $m ->create('CompositeIntOnly');
			$intOnly->id1 = 12;
			$intOnly->id2 = 113;
			$intOnly->name = 'kit';
			$intOnly->commit();
			//select
			$intOnlys = $m->get('CompositeIntOnly');
			$this->assertTrue($intOnlys[0]->name == 'kit');
			$this->assertTrue($intOnlys[0]->id1 == 12);
			$this->assertTrue($intOnlys[0]->id2 == 113);
			//update
			$intOnlys[0]->name = 'abc';
			$intOnlys[0]->commit();
		}
		
		function testCompositeStringProcess(){
			$m = epManager::instance();
			$intOnly = $m ->create('CompositeStringOnly');
			$intOnly->id1 = 'id1';
			$intOnly->id2 = 'id2';
			$intOnly->name = 'kit';
			$intOnly->commit();
			//select
			$intOnlys = $m->get('CompositeStringOnly');
			$this->assertTrue($intOnlys[0]->name == 'kit');
			$this->assertTrue($intOnlys[0]->id1 == 'id1');
			$this->assertTrue($intOnlys[0]->id2 == 'id2');
			//update
			$intOnlys[0]->name = 'abc';
			$intOnlys[0]->commit();
		}
		
		function testCompositeIntStringProcess(){
			$m = epManager::instance();
			$intOnly = $m ->create('CompositeIntString');
			$intOnly->id1 = 'id1';
			$intOnly->id2 = 123;
			$intOnly->name = 'kit';
			$intOnly->commit();
			//select
			$intOnlys = $m->get('CompositeIntString');
			$this->assertTrue($intOnlys[0]->name == 'kit');
			$this->assertTrue($intOnlys[0]->id1 == 'id1');
			$this->assertTrue($intOnlys[0]->id2 == 123);
			//update
			$intOnlys[0]->name = 'abc';
			$intOnlys[0]->commit();
		}
//		
//		function testToy(){
//			$m = epManager::instance();
//			$cm = $m->getClassMap('Toy');
//			$fms = $cm->getAllFields();
//			foreach($fms as $fm){
//				echo $fm->getName().'<br>';
//				echo $fm->isID().'<br>';
//				echo $fm->getFK().'<br>';
//			}
//		}
	}
	
	$test = &new CompositeIDTest();
 	$test->run(new HtmlReporter());
?>
