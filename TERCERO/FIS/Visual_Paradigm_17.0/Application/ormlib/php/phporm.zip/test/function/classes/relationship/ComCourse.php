<?php
	class ComCourse{
		/**
		 * @var string
		 * @orm id char
		 * @dbva id(assigned)
		*/
		private $courseID;
		
		/**
		 * @var int
		 * @orm id2 int
		 * @dbva id(assigned)
		*/
		private $courseID2;
		
		/**
		 * @var string
		 * @orm name char
		*/
		private $coursename;
	 	
	 	/**
	 	 * @orm composed_of many ComStudent
	 	 * @dbva jointable(com_course_student) fk(courseID,courseID2) inversefk(studentID,studentID2)
	 	 */
	 	 private $students;
		
		public function &getCourseID() {
			return $this->courseID;
		}
		
		public function setCourseID(&$courseID) {
			$this->courseID = $courseID;
		}
		
		public function &getCourseID2() {
			return $this->courseID2;
		}
		
		public function setCourseID2(&$courseID2) {
			$this->courseID2 = $courseID2;
		}
		
		public function &getCoursename() {
			return $this->coursename;
		}
		
		public function setCoursename(&$coursename) {
			$this->coursename = $coursename;
		}
		
		public function &getStudents() {
			return $this->students;
		}
		
		public function setStudents(&$students) {
			$this->students = $students;
		}
	 }
?>
