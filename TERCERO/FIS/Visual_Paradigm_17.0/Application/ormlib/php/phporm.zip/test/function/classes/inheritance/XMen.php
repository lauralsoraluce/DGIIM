<?php
/**
 * @dbva inherit(tablePerSubClass,fk(id)) discriminator-value(3)
 */
class XMen extends Professor{
	/**
	 * @var string
	 * @orm xxx char
	 */
	private $xxx;

	public function &getXxx() {
		return $this->xxx;
	}

	public function setXxx(&$xxx) {
		$this->xxx = $xxx;
	}
}
?>
