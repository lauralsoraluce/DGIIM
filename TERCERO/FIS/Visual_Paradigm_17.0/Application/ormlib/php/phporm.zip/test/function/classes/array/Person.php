<?php

class Person {
	/**
	 * @var string
	 * @orm name char
	 */	
	private $pName;
	
	/**
	 * @var string
	 * @orm contactNo char
	 * @dbva array(keyColumn(id),index(contactIndex,int),person_contact)
	 */
	private $contactNo;
	
	/**
	 * @var string
	 * @orm address char
	 */
	private $address;

	public function &getPName() {
		return $this->pName;
	}

	public function setPName(&$pName) {
		$this->pName = $pName;
	}

	public function &getContactNo() {
		return $this->contactNo;
	}

	public function setContactNo(&$contactNo) {
		$this->contactNo = $contactNo;
	}

	public function &getAddress() {
		return $this->address;
	}

	public function setAddress(&$address) {
		$this->address = $address;
	}
}
?>


