<?php
/*
 * Created on Aug 13, 2005 4:36:48 PM
 * author : Administrator
 */
 class Child{
 	/**
 	 * @var int
 	 * @orm childid int
 	 * @dbva id(autogenerate)
 	 */
 	private $childId;
 	
// 	/**
// 	 * @var string
// 	 * @orm childid2 char
// 	 * @dbva id(assigned)
// 	 */
// 	public $childId2;
 	
 	/**
 	 * @var string
 	 * @orm childName char
 	 */
 	private $childName;
 	
 	/**
 	 * @orm has one Toy 
 	 * @dbva inverse(childid)
 	 */
 	private $toy;

 	public function &getChildId() {
 		return $this->childId;
 	}

 	public function setChildId(&$childId) {
 		$this->childId = $childId;
 	}

 	public function &getChildName() {
 		return $this->childName;
 	}

 	public function setChildName(&$childName) {
 		$this->childName = $childName;
 	}

 	public function &getToy() {
 		return $this->toy;
 	}

 	public function setToy(&$toy) {
 		$this->toy = $toy;
 	}
 }
 
?>
