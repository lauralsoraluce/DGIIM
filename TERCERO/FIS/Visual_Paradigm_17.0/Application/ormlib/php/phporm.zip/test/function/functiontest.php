<?php
/*
 * Created on Jul 29, 2005
 *
 */
 	require_once( realpath(dirname(__FILE__)).'/../../ezpdo_runtime.php');
  	require_once(realpath(dirname(__FILE__)).'/../../libs/simpletest/unit_tester.php');
  	require_once(realpath(dirname(__FILE__)).'/../../libs/simpletest/reporter.php');  	
//	$link = mysql_connect('localhost', 'root', '');
//	if (!$link) {
//		die('Could not connect: ' . mysql_error());
//		return;
//	}  	
//  	echo 'Connected successfully <br>';
// 	mysql_query('Drop Database ezpdo');
//	mysql_query('CREATE DATABASE ezpdo;');
//	mysql_close($link);
//	
  	class FunctionTest extends GroupTest {
  		function FunctionTest() {
  			$this->GroupTest('Functional test');
  			$this->addTestFile(dirname(__FILE__) . '/NullValueTest.php');
  			$this->addTestFile(dirname(__FILE__) . '/AssignedIDTest.php');
//  			$this->addTestFile(dirname(__FILE__) . '/CompositeIDTest.php'); 
  		}
  	}
  	
  	$test = &new FunctionTest();
 	$test->run(new HtmlReporter());
 	
?>
