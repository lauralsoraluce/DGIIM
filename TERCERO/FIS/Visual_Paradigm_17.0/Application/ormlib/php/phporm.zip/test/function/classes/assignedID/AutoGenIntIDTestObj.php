<?php
/*
 * Created on Jul 30, 2005 9:15:57 AM
 * author : mingkit
 */
 class AutoGenIntIDTestObj {
	/**
	 * @var int
	 * @orm int
	 * @dbva id(autogenerate)
	 */
	private $id;
	
	/**
	 * @var string
	 * @orm char(20)
	 */
	private $name;

	public function &getId() {
		return $this->id;
	}

	public function setId(&$id) {
		$this->id = $id;
	}

	public function &getName() {
		return $this->name;
	}

	public function setName(&$name) {
		$this->name = $name;
	}
}
?>
