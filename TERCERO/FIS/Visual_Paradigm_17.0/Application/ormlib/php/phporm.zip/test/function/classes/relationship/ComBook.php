<?php

	class ComBook{
		/**
 	 	 * @var string
 		 * @orm bookid char
 	 	 * @dbva id(assigned)
 	 	 */
		private $bookid;
		
		/**
 	 	 * @var int
 		 * @orm bookid2 int
 	 	 * @dbva id(assigned)
 	 	 */
		private $bookid2;
		
 		/**
 		 * @orm has one ComAuthor
 		 * @dbva fk(author,author2)
 		 */
 		private $authorvar;
 		
 		/**
 		 * @var string
 		 * @orm bookName char
 		 */
 		private $bookName;
 	
 		public function &getBookid() {
 			return $this->bookid;
 		}
 	
 		public function setBookid(&$bookid) {
 			$this->bookid = $bookid;
 		}
 	
 		public function &getBookid2() {
 			return $this->bookid2;
 		}
 	
 		public function setBookid2(&$bookid2) {
 			$this->bookid2 = $bookid2;
 		}
 	
 		public function &getAuthorvar() {
 			return $this->authorvar;
 		}
 	
 		public function setAuthorvar(&$authorvar) {
 			$this->authorvar = $authorvar;
 		}
 	
 		public function &getBookName() {
 			return $this->bookName;
 		}
 	
 		public function setBookName(&$bookName) {
 			$this->bookName = $bookName;
 		}
 	}
?>
