<?php
class Doctrine_RepositoryTestCase extends Doctrine_UnitTestCase {
    public function testAdd() {
    }
}
