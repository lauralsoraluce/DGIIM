var searchData=
[
  ['pila_5fmax_2ecpp_12',['pila_max.cpp',['../pila__max_8cpp.html',1,'']]],
  ['pop_13',['Pop',['../classMaxQueue.html#a02898064289387c917f6c0ce9a3c64c4',1,'MaxQueue::Pop()'],['../classMaxStack.html#adcf24f1fb3c2a0f0fa4f93e1cc7b434f',1,'MaxStack::Pop()']]],
  ['push_14',['Push',['../classMaxQueue.html#a3858841f13c5dcbc8140cd1f952de841',1,'MaxQueue::Push()'],['../classMaxStack.html#a11fccd1939974609efbe5a93bc30699d',1,'MaxStack::Push()']]]
];
