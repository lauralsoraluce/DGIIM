var searchData=
[
  ['empty_3',['Empty',['../classMaxQueue.html#af7191c56d598a18e6a2d83b60e6909a6',1,'MaxQueue::Empty()'],['../classMaxStack.html#acadd8cd1f8ec7f9259962641b8fce2d4',1,'MaxStack::Empty()']]]
];
