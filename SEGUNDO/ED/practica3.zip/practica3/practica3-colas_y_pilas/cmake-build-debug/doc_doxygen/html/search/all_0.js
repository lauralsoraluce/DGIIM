var searchData=
[
  ['datos_0',['datos',['../structdatos.html',1,'']]],
  ['de_20una_20pila_1',['de una pila',['../repersentaci_xC3_xB3n.html',1,'']]],
  ['de_20una_20cola_2',['de una cola',['../representaci_xC3_xB3n.html',1,'']]]
];
