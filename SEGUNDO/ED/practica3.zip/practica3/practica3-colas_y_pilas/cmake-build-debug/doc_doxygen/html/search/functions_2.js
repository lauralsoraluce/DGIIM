var searchData=
[
  ['pop_27',['Pop',['../classMaxQueue.html#a02898064289387c917f6c0ce9a3c64c4',1,'MaxQueue::Pop()'],['../classMaxStack.html#adcf24f1fb3c2a0f0fa4f93e1cc7b434f',1,'MaxStack::Pop()']]],
  ['push_28',['Push',['../classMaxQueue.html#a3858841f13c5dcbc8140cd1f952de841',1,'MaxQueue::Push()'],['../classMaxStack.html#a11fccd1939974609efbe5a93bc30699d',1,'MaxStack::Push()']]]
];
