var searchData=
[
  ['size_29',['Size',['../classMaxQueue.html#ac15a51c123f036da714dba0a7c2dcccb',1,'MaxQueue::Size()'],['../classMaxStack.html#add731d0d4fb7ef103c084e619ab443bd',1,'MaxStack::Size()']]]
];
