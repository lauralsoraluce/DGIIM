var searchData=
[
  ['de_20una_20pila_31',['de una pila',['../repersentaci_xC3_xB3n.html',1,'']]],
  ['de_20una_20cola_32',['de una cola',['../representaci_xC3_xB3n.html',1,'']]]
];
