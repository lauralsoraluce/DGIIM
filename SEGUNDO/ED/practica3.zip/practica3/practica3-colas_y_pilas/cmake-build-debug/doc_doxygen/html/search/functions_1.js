var searchData=
[
  ['front_26',['Front',['../classMaxQueue.html#a77c822801206f97cc5afa9f487f853e5',1,'MaxQueue']]]
];
