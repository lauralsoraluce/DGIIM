var indexSectionsWithContent =
{
  0: "abcdegilmosw",
  1: "bcdil",
  2: "bdl",
  3: "abcdegilosw",
  4: "o",
  5: "dm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Friends",
  5: "Pages"
};

