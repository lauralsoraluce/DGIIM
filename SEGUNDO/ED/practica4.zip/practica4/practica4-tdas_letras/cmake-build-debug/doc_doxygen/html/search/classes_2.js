var searchData=
[
  ['dictionary_37',['Dictionary',['../classDictionary.html',1,'']]]
];
