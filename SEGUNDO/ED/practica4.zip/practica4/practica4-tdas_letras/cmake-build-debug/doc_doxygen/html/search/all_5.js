var searchData=
[
  ['get_15',['get',['../classBag.html#ab733fc91f41bcaefb07f5d37b0bd5627',1,'Bag']]],
  ['getocurrences_16',['getOcurrences',['../classDictionary.html#a3dfa0c8a08380b6b1dcb00fe1964bb11',1,'Dictionary']]],
  ['getscore_17',['getScore',['../classLettersSet.html#abd8ffbaf64e0ea4d097278ec8e20a011',1,'LettersSet']]],
  ['gettotalletters_18',['getTotalLetters',['../classDictionary.html#ac3b8bd67f0a45918cfe868e9e62f2322',1,'Dictionary']]]
];
