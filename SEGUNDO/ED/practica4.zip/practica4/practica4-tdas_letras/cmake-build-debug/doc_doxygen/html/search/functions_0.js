var searchData=
[
  ['add_47',['add',['../classBag.html#af5f86444fd1c4bfbfe11e602ffac697b',1,'Bag']]]
];
