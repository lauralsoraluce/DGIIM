var searchData=
[
  ['empty_58',['empty',['../classBag.html#abd0eb2d3143fc0ca9edf5fe9083b0587',1,'Bag::empty()'],['../classDictionary.html#ab45dc9793957e562ccc104150fc7af8f',1,'Dictionary::empty()'],['../classLettersSet.html#aa94569c5875ddb88b4c5aa7d3e6c9120',1,'LettersSet::empty()']]],
  ['erase_59',['erase',['../classDictionary.html#ade0c02d2c1f45e826a87f52c4f1d0ee6',1,'Dictionary::erase()'],['../classLettersSet.html#a97a0a1ec618aad0bce8a6a275f546995',1,'LettersSet::erase()']]],
  ['exists_60',['exists',['../classDictionary.html#a271c7a91f40d15b8f2b35d0ca79d5c64',1,'Dictionary']]],
  ['extractletter_61',['extractLetter',['../classLettersBag.html#a64eb87aa50f1903c52681e38557d1cda',1,'LettersBag']]],
  ['extractletters_62',['extractLetters',['../classLettersBag.html#af7e58ec96acdf06049c74e6e00084d9b',1,'LettersBag']]]
];
