var searchData=
[
  ['dictionary_41',['Dictionary',['../classDictionary.html',1,'']]]
];
