var searchData=
[
  ['get_63',['get',['../classBag.html#ab733fc91f41bcaefb07f5d37b0bd5627',1,'Bag']]],
  ['getocurrences_64',['getOcurrences',['../classDictionary.html#a3dfa0c8a08380b6b1dcb00fe1964bb11',1,'Dictionary']]],
  ['getscore_65',['getScore',['../classLettersSet.html#abd8ffbaf64e0ea4d097278ec8e20a011',1,'LettersSet']]],
  ['getsolutions_66',['getSolutions',['../classSolver.html#a2b6bca08ff578e9b161168cc1832fbd7',1,'Solver']]],
  ['gettotalletters_67',['getTotalLetters',['../classDictionary.html#ac3b8bd67f0a45918cfe868e9e62f2322',1,'Dictionary']]]
];
