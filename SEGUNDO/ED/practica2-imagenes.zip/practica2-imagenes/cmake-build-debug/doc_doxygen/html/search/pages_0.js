var searchData=
[
  ['representación_20del_20tda_20imagen_20_2e_55',['Representación del TDA Imagen .',['../repImagen.html',1,'']]]
];
