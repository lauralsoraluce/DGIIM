var searchData=
[
  ['save_19',['Save',['../classImage.html#adde1007dc6359087dae65fa8cae26448',1,'Image']]],
  ['set_5fpixel_20',['set_pixel',['../classImage.html#a6e316f867fd3b67a75d78ca66bc12195',1,'Image::set_pixel(int i, int j, byte value)'],['../classImage.html#adf54cab55e991b8fac7d8043507588cb',1,'Image::set_pixel(int k, byte value)']]],
  ['shufflerows_21',['ShuffleRows',['../classImage.html#a27d5bab7af11a729048b82af06f2d0c0',1,'Image']]],
  ['size_22',['size',['../classImage.html#a78068ea10fef9954ea0e91705997652d',1,'Image']]],
  ['subsample_23',['Subsample',['../classImage.html#aa00e596a67ec6130922c560049457985',1,'Image']]]
];
