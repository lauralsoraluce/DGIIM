#encoding:utf-8

module Deepspace
	module ShotResult
		DONOTRESIST=:donotresist
		RESIST=:resist
	end
end
