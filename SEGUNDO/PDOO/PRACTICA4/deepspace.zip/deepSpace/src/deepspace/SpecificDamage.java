/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deepspace;

import java.util.ArrayList;

/**
 *
 * @author joarpe
 */
public class SpecificDamage extends Damage {
    private ArrayList<WeaponType> weapons;
    
    SpecificDamage (ArrayList<WeaponType> wl, int s) {
        super (s);
        
        if (wl != null) {
            weapons = new ArrayList(wl);
        }
        else {
            weapons = new ArrayList<>();
        }
    }
    
    @Override
    public SpecificDamage copy () {
        return (new SpecificDamage(weapons, this.getNShields()));
    }
    
    public SpecificDamageToUI getUIversion () {
        return (new SpecificDamageToUI(this));
    }
    
    private int arrayContainsType (ArrayList<Weapon> w, WeaponType t) {
        return w.indexOf(t);
    }
    
    @Override
    public Damage adjust (ArrayList<Weapon> w, ArrayList<ShieldBooster> s) {
        int nS = adjustShields(s);
        
        ArrayList<WeaponType> weap_type = new ArrayList <>();
        ArrayList<Weapon> weap = new ArrayList (w);

        for (int i = 0; i < weapons.size(); ++i) {
            int index = arrayContainsType(weap, weapons.get(i));

            if (index != -1) {
                weap_type.add(weapons.get(i));
                weap.remove(index);
            }
        }

        return new SpecificDamage (weap_type, nS);
    }
    
    @Override
    public void discardWeapon (Weapon w) {
        if (!weapons.isEmpty()) {
            weapons.remove(w.getType());
        }
    }
    
    @Override
    public boolean hasNoEffect () {
        return (super.hasNoEffect() && weapons.isEmpty());
    }
    
    public ArrayList<WeaponType> getWeapons () {
        return weapons;
    }
    
    @Override
    public  String toString () {
        return (super.toString() + getUIversion().getWeaponInfo());
    }
}
