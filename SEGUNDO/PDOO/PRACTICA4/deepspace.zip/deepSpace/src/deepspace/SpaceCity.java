/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deepspace;

import java.util.ArrayList;

/**
 *
 * @author joarpe
 */
public class SpaceCity extends SpaceStation {
    private SpaceStation base;
    private ArrayList<SpaceStation> collaborators;
    
    public SpaceCity (SpaceStation base, ArrayList<SpaceStation> rest) {
        super(base);
        this.base = base;
        collaborators = new ArrayList (rest);
    }
    
    public ArrayList<SpaceStation> getCollaborators () {
        return collaborators;
    }
    
    @Override
    public float fire () {
        float fire = base.fire();
        
        for (SpaceStation station : collaborators) {
            fire += station.fire();
        }
        
        return fire;
    }
    
    @Override
    public float protection () {
        float shield = base.protection();
        
        for (SpaceStation station : collaborators) {
            shield += station.protection();
        }
        
        return shield;
    }
    
    @Override
    public Transformation setLoot (Loot loot) {
        super.setLoot(loot);
        
        return Transformation.NOTRANSFORM;
    }
}
