/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deepspace;

import java.util.ArrayList;

/**
 *
 * @author joarpe
 */
public abstract class Damage {
    //private static int NOT_USED = -1;
    //private int nShields, nWeapons;
    private int nShields;
    //private ArrayList<WeaponType> weapons;
    
    /*Damage (int w, int s) {
        nShields = s;
        nWeapons = w;
        weapons = new ArrayList<>();
    }*/
    
    Damage (int s) {
        nShields = s;
    }
    
    /*Damage (ArrayList<WeaponType> wl, int s) {
        nShields = s;
        nWeapons = NOT_USED;
        weapons = new ArrayList (wl);
    }*/
    
    public abstract Damage copy();
    
    /*Damage (Damage d) {
        this(d.getNWeapons(), d.getNShields());
        weapons = new ArrayList(d.getWeapons());
    }*/
    
     public abstract DamageToUI getUIversion ();
    
    /*private int arrayContainsType (ArrayList<Weapon> w, WeaponType t) {
        return w.indexOf(t);
    }*/
    
    public int adjustShields (ArrayList<ShieldBooster> s) {
        int nS = nShields;
        
        if (s.size() < nShields) {
            nS = s.size();
        }
        
        return nS;
    }
    
    public abstract Damage adjust (ArrayList<Weapon> w, ArrayList<ShieldBooster> s);
    /*{
        int nS = nShields;
        int nW = nWeapons;
        // Metodo auxiliar
        if (s.size() < nShields) {
            nS = s.size();
        }
        
        if (w.size() < nWeapons) {
            nW = w.size();
            
            return new Damage (nW, nS);
        }
        
        else {
            ArrayList<WeaponType> weap_type = new ArrayList <>();
            ArrayList<Weapon> weap = new ArrayList (w);
            
            for (int i = 0; i < weapons.size(); ++i) {
                int index = arrayContainsType(weap, weapons.get(i));

                if (index != -1) {
                    weap_type.add(weapons.get(i));
                    weap.remove(index);
                }
            }
            
            return new Damage (weap_type, nS);
        }
    }*/
    
    public abstract void discardWeapon (Weapon w); //Probar quitando este metodo de la clase padre y definiendolos en las hijas
    
    public void discardShieldBooster () {
        if (nShields > 0) {
            nShields--;
        }
    }
    
    /*public boolean hasNoEffect () {
        return ((nShields == 0) && (nWeapons == 0 || weapons.isEmpty()));
    }*/
    
    public boolean hasNoEffect () {
        return (nShields == 0);
    }
    
    public int getNShields () {
        return nShields;
    }
    
    /*public int getNWeapons () {
        return nWeapons;
    }*/
    
    /*public ArrayList<WeaponType> getWeapons () {
        return weapons;
    }*/
    
    public String toString () {
        return ""+nShields;
    }
}

