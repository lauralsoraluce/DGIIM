/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deepspace;

import java.util.ArrayList;

/**
 *
 * @author joarpe
 */
public class SpaceStation implements SpaceFighter {
    private static final int MAXFUEL = 100;
    private static final double SHIELDLOSSPERUNITSHOT = 0.1;
    private float ammoPower;
    private float fuelUnits;
    private String name;
    private int nMedals;
    private float shieldPower;
    private Damage pendingDamage;
    private ArrayList<Weapon> weapons;
    private ArrayList<ShieldBooster> shieldBoosters;
    private Hangar hangar;
    
    private void assignFuelValue (float f) {
        if (f <= MAXFUEL) {
            fuelUnits = f;
        }
        else {
            fuelUnits = MAXFUEL;
        }
    }
    
    private void cleanPendingDamage () {
        if (pendingDamage != null) {
            if (pendingDamage.hasNoEffect()) {
                pendingDamage = null;
            }
        }
    }
    
    SpaceStation (String n, SuppliesPackage supplies) {
        name = n;
        ammoPower = 0.0f;
        fuelUnits = 0.0f;
        shieldPower = 0.0f;
        receiveSupplies(supplies);
        nMedals = 0;
        weapons = new ArrayList<>();
        shieldBoosters = new ArrayList<>();
        pendingDamage = null;
        hangar = null;
    }
    
    SpaceStation (SpaceStation station) {
        this(station.name, new SuppliesPackage(station.ammoPower, station.fuelUnits, station.shieldPower));
        nMedals = station.nMedals;
        weapons = new ArrayList (station.weapons);
        shieldBoosters = new ArrayList (station.shieldBoosters);
        
        if (station.pendingDamage != null) {
            pendingDamage = station.pendingDamage.copy();
        }
        
        if (station.hangar != null) {
            hangar = new Hangar (station.hangar);
        }
    }
    
    public void cleanUpMountedItems () {
        for (int i = 0; i < weapons.size(); ++i) {
            if (weapons.get(i).getUses() == 0) {
                weapons.remove(i);
                i--;
            }
        }
        
        for (int i = 0; i < shieldBoosters.size(); ++i) {
            if (shieldBoosters.get(i).getUses() == 0) {
                shieldBoosters.remove(i);
                i--;
            }
        }
    }
    
    public void discardHangar () {
        hangar = null;
    }
    
    public void discardShieldBooster (int i) {
        int size = shieldBoosters.size();
        
        if (i >= 0 && i < size) {
            shieldBoosters.remove(i);
            
            if (pendingDamage != null) {
                pendingDamage.discardShieldBooster();
                cleanPendingDamage();
            }
        }
    }
    
    public void discardShieldBoosterInHangar (int i) {
        if (hangar != null) {
            hangar.removeShieldBooster(i);
        }
    }
    
    public void discardWeapon (int i) {
        int size = weapons.size();
        
        if (i >= 0 && i < size) {
            Weapon w = weapons.remove(i);
            
            if (pendingDamage != null) {
                pendingDamage.discardWeapon(w);
                cleanPendingDamage();
            }
        }
    }
    
    public void discardWeaponInHangar (int i) {
        if (hangar != null) {
            hangar.removeWeapon(i);
        }
    }
    
    @Override
    public float fire () {
        int size = weapons.size();
        float factor = 1.0f;
        
        for (int i = 0; i < size; ++i) {
            Weapon w = weapons.get(i);
            factor *= w.useIt();
        }
        
        return (ammoPower * factor);
    }
    
    public float getAmmoPower () {
        return ammoPower;
    }
    
    public float getFuelUnits () {
        return fuelUnits;
    }
    
    public Hangar getHangar () {
        return hangar;
    }
    
    public String getName () {
        return name;
    }
    
    public int getNMedals () {
        return nMedals;
    }
    
    public Damage getPendingDamage () {
        return pendingDamage;
    }
    
    public ArrayList<ShieldBooster> getShieldBoosters () {
        return shieldBoosters;
    }
    
    public float getShieldPower () {
        return shieldPower;
    }
    
    public float getSpeed () {
        float f;
        
        f = fuelUnits / MAXFUEL;
        
        return f;
    }
    
    public SpaceStationToUI getUIversion () {
        return (new SpaceStationToUI(this));
    }
    
    public ArrayList<Weapon> getWeapons () {
        return weapons;
    }
    
    public void mountShieldBooster (int i) {     
        if (hangar != null) {
            ShieldBooster aux = hangar.removeShieldBooster(i);
            
            if (aux != null) {
                shieldBoosters.add(aux);
            }
        }
    }
    
    public void mountWeapon (int i) {
        if (hangar != null) {
            Weapon aux = hangar.removeWeapon(i);
            
            if (aux != null) {
                weapons.add(aux);
            }
        }
    }
    
    public void move () {
        fuelUnits -= getSpeed();
        
        if (fuelUnits < 0) {
            fuelUnits = 0;
        }
    }
    
    @Override
    public float protection () {
        int size = shieldBoosters.size();
        float factor = 1.0f;
        
        for (int i = 0; i < size; ++i) {
            ShieldBooster s = shieldBoosters.get(i);
            factor *= s.useIt();
        }
        
        return (shieldPower * factor);
    }
    
    public void receiveHangar (Hangar h) {
        if (hangar == null) {
            hangar = h;
        }
    }
    
    public boolean receiveShieldBooster (ShieldBooster s) {
        if (hangar != null) {
            return hangar.addShieldBoosters(s);
        }
        
        else {
            return false;
        }
    }
    
    @Override
    public ShotResult receiveShot (float shot) {
        float myProtection = protection();
        
        if (myProtection >= shot) {
            shieldPower -= SHIELDLOSSPERUNITSHOT * shot;
            
            if (0.0f > shieldPower) {
                shieldPower = 0.0f;
            }
            
            return ShotResult.RESIST;
        }
        
        else {
            shieldPower = 0.0f;
            
            return ShotResult.DONOTRESIST;
        }
    }
    
    public void receiveSupplies (SuppliesPackage s) {
        ammoPower += s.getAmmoPower();
        shieldPower += s.getShieldPower();
        assignFuelValue(fuelUnits + s.getFuelUnits());
    }
    
    public boolean receiveWeapon (Weapon w) {
        if (hangar != null) {
            return hangar.addWeapon(w);
        }
        
        else {
            return false;
        }
    }
    
    public Transformation setLoot (Loot loot) {
        CardDealer dealer = CardDealer.getInstance();
        int h = loot.getNHangars();

        if (h > 0) {
            hangar = dealer.nextHangar();
            receiveHangar(hangar);
        }
        
        int elements = loot.getNSupplies();
        
        for (int i = 0; i < elements; ++i) {
            SuppliesPackage sup = dealer.nextSuppliesPackage();
            receiveSupplies(sup);
        }
        
        elements = loot.getNWeapons();
        
        for (int i = 0; i < elements; ++i) {
            Weapon weap = dealer.nextWeapon();
            receiveWeapon(weap);
        }
        
        elements = loot.getNShields();
        
        for (int i = 0; i < elements; ++i) {
            ShieldBooster sh = dealer.nextShieldBooster();
            receiveShieldBooster(sh);
        }
        
        int medals = loot.getNMedals();
        
        nMedals += medals;
        
        if (loot.getEfficient()) {
            return Transformation.GETEFFICIENT;
        }
        else {
            if (loot.spaceCity()) {
                return Transformation.SPACECITY;
            }
            else{
                return Transformation.NOTRANSFORM;
            }
        }
    }
    
    public void setPendingDamage (Damage d) {
        if (d != null) {
            pendingDamage = d.adjust(weapons, shieldBoosters);
        }
    }
    
    public boolean validState () {
        if (pendingDamage == null) {
            return true;
        }
        else {
            return pendingDamage.hasNoEffect();
        }
    }
    
    public String toString () {
        return getUIversion().toString();
    }
}
